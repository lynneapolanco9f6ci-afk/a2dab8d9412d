// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("linux ppc64le\n", stdout);
  return lionss_run_workload("linux-ppc64le");
}

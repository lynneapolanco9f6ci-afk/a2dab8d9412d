// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cache bench\n", stdout);
  return lionss_run_workload("cache-bench");
}

// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("macos universal\n", stdout);
  return lionss_run_workload("macos-universal");
}

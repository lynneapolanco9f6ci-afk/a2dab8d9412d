// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("configure minimal\n", stdout);
  return lionss_run_workload("configure-minimal");
}
